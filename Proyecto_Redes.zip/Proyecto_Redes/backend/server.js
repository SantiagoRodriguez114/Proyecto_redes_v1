import express from "express";
import cors from "cors";
import { initDB, openDB } from "./database.js";

const app = express();
app.use(cors());
app.use(express.json());

await initDB();

// ========= ENDPOINT 1: recibir datos del gateway =========
app.post("/api/recibir", async (req, res) => {
  const { nodo, clave, valor, timestamp } = req.body;

  if (!nodo || !clave || !valor || !timestamp) {
    return res.status(400).json({ error: "Datos incompletos" });
  }

  const db = await openDB();
  await db.run(
    "INSERT INTO datos (nodo, clave, valor, timestamp) VALUES (?, ?, ?, ?)",
    [nodo, clave, valor, timestamp]
  );

  console.log(`[OK] ${nodo} → ${clave}:${valor}`);

  res.json({ success: true });
});

// ========= ENDPOINT 2: obtener todos los datos =========
app.get("/api/datos", async (req, res) => {
  const db = await openDB();
  const rows = await db.all("SELECT * FROM datos ORDER BY id DESC");
  res.json(rows);
});

// ========= ENDPOINT 3: nodos activos =========
app.get("/api/activos", async (req, res) => {
  const db = await openDB();
  const now = Math.floor(Date.now() / 1000);

  const rows = await db.all(
    "SELECT DISTINCT nodo FROM datos WHERE timestamp > ?",
    [now - 30]    // activo si reportó en los últimos 30 segundos
  );

  res.json(rows.map(r => r.nodo));
});

// ========= ENDPOINT 4: última lectura de un nodo =========
app.get("/api/ultimo/:nodo", async (req, res) => {
  const nodo = req.params.nodo.toUpperCase();

  const db = await openDB();
  const row = await db.get(
    "SELECT * FROM datos WHERE nodo=? ORDER BY id DESC LIMIT 1",
    [nodo]
  );

  if (!row) return res.status(404).json({ error: "Nodo no encontrado" });

  res.json(row);
});


// ========= PUERTO =========
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Backend listo en puerto ${PORT}`));

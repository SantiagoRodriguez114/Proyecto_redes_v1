#!/bin/bash
# ============================
MY_IP="172.25.5.86"
PEER_IP_A="172.25.6.210"
PEER_IP_B="172.25.8.1"
PEER_IP_D="172.25.9.220"
PEER_IP_G="172.25.10.238"

IFACE="CAMBIAR_A_TU_INTERFAZ"
# ============================

sudo modprobe batman_adv
sudo ip link add bat0 type batadv
sudo ip link set bat0 up

# CA
sudo ip link add vxlanCA type vxlan id 20 dstport 4789 remote $PEER_IP_A local $MY_IP dev $IFACE
sudo ip link set vxlanCA up
sudo batctl if add vxlanCA

# CB
sudo ip link add vxlanCB type vxlan id 50 dstport 4789 remote $PEER_IP_B local $MY_IP dev $IFACE
sudo ip link set vxlanCB up
sudo batctl if add vxlanCB

#CD
sudo ip link add vxlanCD type vxlan id 110 dstport 4789 remote $PEER_IP_D local $MY_IP dev $IFACE
sudo ip link set vxlanCD up
sudo batctl if add vxlanCD

# CG
sudo ip link add vxlanCG type vxlan id 90 dstport 4789 remote $PEER_IP_G local $MY_IP dev $IFACE
sudo ip link set vxlanCG up
sudo batctl if add vxlanCG

echo "[✓] Nodo C listo."

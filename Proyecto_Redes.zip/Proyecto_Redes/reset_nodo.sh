#!/bin/bash

echo "==============================================="
echo "  REINICIO COMPLETO DEL NODO – LIMPIEZA BATMAN"
echo "==============================================="

### APAGAR batman-adv
echo "[*] Eliminando interfaz bat0..."
sudo ip link set bat0 down 2>/dev/null
sudo ip link delete bat0 type batadv 2>/dev/null

### ELIMINAR TODAS LAS VXLAN DEL NODO
echo "[*] Buscando y eliminando interfaces VXLAN..."

for vx in $(ip -o link show | awk -F': ' '{print $2}' | grep vxlan); do
    echo "    - Eliminando $vx..."
    sudo ip link set $vx down 2>/dev/null
    sudo ip link delete $vx 2>/dev/null
done

### LIMPIAR RUTAS (opcional pero recomendado)
echo "[*] Limpiando rutas huérfanas..."
sudo ip route flush table main

### LIMPIAR ARP
echo "[*] Limpiando tabla ARP..."
sudo ip neigh flush all

### VOLVER A ACTIVAR RED
echo "[*] Reiniciando servicio de red..."
if command -v systemctl >/dev/null; then
    sudo systemctl restart NetworkManager 2>/dev/null || sudo systemctl restart networking 2>/dev/null
fi

echo "==============================================="
echo "     NODO LIMPIO. LISTO PARA NUEVO SETUP"
echo "==============================================="

echo "Ahora ejecuta:"
echo "sudo ./setup_node_A.sh   (o B, C, D)"
